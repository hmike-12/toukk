<?php
include '../config/database.php';
include '../includes/header.php';

$kategori = mysqli_query($conn, "SELECT * FROM kategori");
?>

<div class="container mt-4">
    <h2>Data Kategori</h2>
    <a href="tambah.php" class="btn btn-primary mb-3">Tambah Kategori</a>
    <table class="table table-bordered">
        <tr><th>ID</th><th>Nama Kategori</th><th>Aksi</th></tr>
        <?php while ($k = mysqli_fetch_assoc($kategori)) : ?>
        <tr>
            <td><?= $k['id'] ?></td>
            <td><?= $k['nama_kategori'] ?></td>
            <td>
                <a href="edit.php?id=<?= $k['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                <a href="hapus.php?id=<?= $k['id'] ?>" onclick="return confirm('Hapus?')" class="btn btn-danger btn-sm">Hapus</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php include '../includes/footer.php'; ?>

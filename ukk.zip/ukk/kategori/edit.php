<?php
include '../config/database.php';
include '../includes/header.php';

$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM kategori WHERE id=$id"));

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama_kategori'];
    mysqli_query($conn, "UPDATE kategori SET nama_kategori='$nama' WHERE id=$id");
    header("Location: index.php");
}
?>

<div class="container mt-4">
    <h2>Edit Kategori</h2>
    <form method="POST">
        <input type="text" name="nama_kategori" value="<?= $data['nama_kategori'] ?>" class="form-control mb-3" required>
        <button class="btn btn-success">Update</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php include '../includes/footer.php'; ?>


<?php
include '../config/database.php';
include '../includes/header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama_kategori'];
    mysqli_query($conn, "INSERT INTO kategori (nama_kategori) VALUES ('$nama')");
    header("Location: index.php");
}
?>

<div class="container mt-4">
    <h2>Tambah Kategori</h2>
    <form method="POST">
        <input type="text" name="nama_kategori" class="form-control mb-3" required>
        <button class="btn btn-primary">Simpan</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php include '../includes/footer.php'; ?>

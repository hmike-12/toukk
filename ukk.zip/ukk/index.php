<?php include 'includes/header.php'; ?>
<div class="container mt-5">
    <h1>Selamat Datang di Sistem Inventaris Barang</h1>
    <p>Silakan gunakan menu di atas untuk mengelola data barang dan kategori.</p>
</div>
<?php include 'includes/footer.php'; ?>

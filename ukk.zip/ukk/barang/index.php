<?php
include '../config/database.php';
include '../includes/header.php';

// Notifikasi
$notif = $_GET['notif'] ?? '';

// Tangkap keyword pencarian
$search = $_GET['cari'] ?? '';

// Export to Excel
if (isset($_GET['export']) && $_GET['export'] == 'excel') {
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="data_barang_'.date('Ymd').'.xls"');
    
    $query = "SELECT b.*, k.nama_kategori 
              FROM barang b 
              LEFT JOIN kategori k ON b.kategori_id = k.id";
    if (!empty($search)) {
        $search_escaped = mysqli_real_escape_string($conn, $search);
        $query .= " WHERE b.nama_barang LIKE '%$search_escaped%' 
                    OR k.nama_kategori LIKE '%$search_escaped%'";
    }
    $result = mysqli_query($conn, $query);
    
    echo "<table border='1'>";
    echo "<tr>
            <th>ID</th>
            <th>Nama Barang</th>
            <th>Kategori</th>
            <th>Stok</th>
            <th>Harga</th>
            <th>Tanggal Masuk</th>
          </tr>";
    
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>".$row['id']."</td>
                <td>".htmlspecialchars($row['nama_barang'])."</td>
                <td>".htmlspecialchars($row['nama_kategori'])."</td>
                <td>".$row['stok']."</td>
                <td>Rp ".number_format($row['harga'], 0, ',', '.')."</td>
                <td>".$row['tanggal_masuk']."</td>
              </tr>";
    }
    echo "</table>";
    exit();
}

// Pagination configuration
$rows_per_page = 10;
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($current_page < 1) $current_page = 1;

// Query for total rows
$count_query = "SELECT COUNT(*) as total FROM barang b LEFT JOIN kategori k ON b.kategori_id = k.id";
if (!empty($search)) {
    $search_escaped = mysqli_real_escape_string($conn, $search);
    $count_query .= " WHERE b.nama_barang LIKE '%$search_escaped%' 
                      OR k.nama_kategori LIKE '%$search_escaped%'";
}
$count_result = mysqli_query($conn, $count_query);
$total_rows = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_rows / $rows_per_page);

if ($current_page > $total_pages && $total_pages > 0) {
    $current_page = $total_pages;
}

$offset = ($current_page - 1) * $rows_per_page;

// Query data barang with pagination
if (!empty($search)) {
    $search_escaped = mysqli_real_escape_string($conn, $search);
    $query = "SELECT b.*, k.nama_kategori 
              FROM barang b 
              LEFT JOIN kategori k ON b.kategori_id = k.id
              WHERE b.nama_barang LIKE '%$search_escaped%' 
              OR k.nama_kategori LIKE '%$search_escaped%'
              LIMIT $offset, $rows_per_page";
} else {
    $query = "SELECT b.*, k.nama_kategori 
              FROM barang b 
              LEFT JOIN kategori k ON b.kategori_id = k.id
              LIMIT $offset, $rows_per_page";
}

$result = mysqli_query($conn, $query);
?>

<div class="container mt-4">
    <h2>Data Barang</h2>
    <!-- Action Buttons -->
    <div class="mb-3 d-flex justify-content-between">
        <!-- Form Pencarian -->
        <form method="GET" class="d-flex">
            <div class="input-group">
                <input type="text" name="cari" class="form-control" placeholder="Cari nama barang atau kategori..." value="<?= htmlspecialchars($search) ?>">
                <button class="btn btn-primary" type="submit">Cari</button>
            </div>
        </form>
        
        <!-- Export Button -->
        <a href="?<?= http_build_query(array_merge($_GET, ['export' => 'excel'])) ?>" class="btn btn-success">
            <i class="fas fa-file-excel"></i> Export Excel
        </a>
    </div>

    <?php if (!empty($search)) : ?>
        <p>Hasil pencarian untuk: <strong><?= htmlspecialchars($search) ?></strong></p>
    <?php endif; ?>

    <!-- Tabel Data -->
    <a href="tambah.php" class="btn btn-primary mb-3">Tambah barang</a>

    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Nama Barang</th>
                    <th>Kategori</th>
                    <th>Stok</th>
                    <th>Harga</th>
                    <th>Tanggal Masuk</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php if (mysqli_num_rows($result) > 0) : ?>
                <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= htmlspecialchars($row['nama_barang']) ?></td>
                        <td><?= htmlspecialchars($row['nama_kategori']) ?></td>
                        <td><?= $row['stok'] ?></td>
                        <td>Rp <?= number_format($row['harga'], 0, ',', '.') ?></td>
                        <td><?= $row['tanggal_masuk'] ?></td>
                        <td>
                            <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="hapus.php?id=<?= $row['id'] ?>" onclick="return confirm('Yakin ingin menghapus?')" class="btn btn-danger btn-sm">Hapus</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else : ?>
                <tr>
                    <td colspan="7" class="text-center">Tidak ada data ditemukan</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php if ($total_pages > 1) : ?>
        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center">
                <!-- First Page -->
                <li class="page-item <?= $current_page == 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => 1])) ?>" aria-label="First">
                        <span aria-hidden="true">&laquo;&laquo;</span>
                    </a>
                </li>
                
                <!-- Previous Page -->
                <li class="page-item <?= $current_page == 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $current_page - 1])) ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                
                <!-- Page Numbers -->
                <?php 
                $start_page = max(1, $current_page - 2);
                $end_page = min($total_pages, $current_page + 2);
                
                if ($start_page > 1) {
                    echo '<li class="page-item disabled"><a class="page-link">...</a></li>';
                }
                
                for ($i = $start_page; $i <= $end_page; $i++) : ?>
                    <li class="page-item <?= $i == $current_page ? 'active' : '' ?>">
                        <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>"><?= $i ?></a>
                    </li>
                <?php endfor;
                
                if ($end_page < $total_pages) {
                    echo '<li class="page-item disabled"><a class="page-link">...</a></li>';
                }
                ?>
                
                <!-- Next Page -->
                <li class="page-item <?= $current_page == $total_pages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $current_page + 1])) ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
                
                <!-- Last Page -->
                <li class="page-item <?= $current_page == $total_pages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $total_pages])) ?>" aria-label="Last">
                        <span aria-hidden="true">&raquo;&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
        
        <div class="text-center text-muted">
            Menampilkan <?= ($offset + 1) ?> - <?= min($offset + $rows_per_page, $total_rows) ?> dari <?= $total_rows ?> data
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>
<?php
include '../config/database.php';
include '../includes/header.php';

$errors = [];
$success = "";

// Ambil data kategori
$kategori = mysqli_query($conn, "SELECT * FROM kategori");

// Proses jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama       = trim($_POST['nama_barang']);
    $kategoriId = $_POST['kategori_id'];
    $stok       = $_POST['stok'];
    $harga      = $_POST['harga'];
    $tanggal    = $_POST['tanggal_masuk'];

    // Validasi
    if (empty($nama)) {
        $errors[] = "Nama barang wajib diisi.";
    }
    if (!is_numeric($stok) || $stok < 0) {
        $errors[] = "Stok harus berupa angka positif.";
    }
    if (!is_numeric($harga) || $harga < 0) {
        $errors[] = "Harga harus berupa angka positif.";
    }

    if (empty($errors)) {
        $stmt = mysqli_prepare($conn, "INSERT INTO barang (nama_barang, kategori_id, stok, harga, tanggal_masuk) VALUES (?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "siiis", $nama, $kategoriId, $stok, $harga, $tanggal);
        mysqli_stmt_execute($stmt);

        // Redirect ke index dengan notifikasi
        header("Location: index.php?notif=Barang berhasil ditambahkan");
        exit;
    }
}
?>

<div class="container mt-4">
    <h2>Tambah Barang</h2>

    <?php if ($errors): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach ($errors as $e) echo "<li>$e</li>"; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label for="nama_barang" class="form-label">Nama Barang</label>
            <input type="text" name="nama_barang" id="nama_barang" class="form-control" value="<?= $_POST['nama_barang'] ?? '' ?>">
        </div>

        <div class="mb-3">
            <label for="kategori_id" class="form-label">Kategori</label>
            <select name="kategori_id" id="kategori_id" class="form-select">
                <option value="">-- Pilih Kategori --</option>
                <?php while ($row = mysqli_fetch_assoc($kategori)) : ?>
                    <option value="<?= $row['id'] ?>" <?= (isset($_POST['kategori_id']) && $_POST['kategori_id'] == $row['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($row['nama_kategori']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="stok" class="form-label">Stok</label>
            <input type="number" name="stok" id="stok" class="form-control" value="<?= $_POST['stok'] ?? '' ?>">
        </div>

        <div class="mb-3">
            <label for="harga" class="form-label">Harga</label>
            <input type="number" name="harga" id="harga" class="form-control" value="<?= $_POST['harga'] ?? '' ?>">
        </div>

        <div class="mb-3">
            <label for="tanggal_masuk" class="form-label">Tanggal Masuk</label>
            <input type="date" name="tanggal_masuk" id="tanggal_masuk" class="form-control" value="<?= $_POST['tanggal_masuk'] ?? date('Y-m-d') ?>">
        </div>

        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php include '../includes/footer.php'; ?>

<?php
include '../config/database.php';
include '../includes/header.php';

$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM barang WHERE id=$id"));
$kategori = mysqli_query($conn, "SELECT * FROM kategori");

if (!$data) die("Data tidak ditemukan.");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama       = $_POST['nama_barang'];
    $kategoriId = $_POST['kategori_id'];
    $stok       = $_POST['stok'];
    $harga      = $_POST['harga'];
    $tanggal    = $_POST['tanggal_masuk'];

    mysqli_query($conn, "UPDATE barang SET 
        nama_barang='$nama', kategori_id='$kategoriId',
        stok='$stok', harga='$harga', tanggal_masuk='$tanggal' 
        WHERE id=$id");

    header("Location: index.php?notif=Barang berhasil diupdate");
    exit;
}
?>

<div class="container mt-4">
    <h2>Edit Barang</h2>
    <form method="POST">
        <input type="text" name="nama_barang" value="<?= $data['nama_barang'] ?>" class="form-control mb-2" required>
        <select name="kategori_id" class="form-select mb-2">
            <?php while ($k = mysqli_fetch_assoc($kategori)) : ?>
                <option value="<?= $k['id'] ?>" <?= $k['id'] == $data['kategori_id'] ? 'selected' : '' ?>>
                    <?= $k['nama_kategori'] ?>
                </option>
            <?php endwhile; ?>
        </select>
        <input type="number" name="stok" value="<?= $data['stok'] ?>" class="form-control mb-2" required>
        <input type="number" name="harga" value="<?= $data['harga'] ?>" class="form-control mb-2" required>
        <input type="date" name="tanggal_masuk" value="<?= $data['tanggal_masuk'] ?>" class="form-control mb-3" required>
        <button class="btn btn-success">Update</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php include '../includes/footer.php'; ?>
